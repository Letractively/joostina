# phpMyAdmin MySQL-Dump
# version 2.5.1
# http://www.phpmyadmin.net/ (download page)
#
# --------------------------------------------------------

DROP TABLE IF EXISTS mos_banner;
DROP TABLE IF EXISTS mos_bannerclient;
DROP TABLE IF EXISTS mos_bannerfinish;
DROP TABLE IF EXISTS mos_categories;
DROP TABLE IF EXISTS mos_components;
DROP TABLE IF EXISTS mos_contact_details;
DROP TABLE IF EXISTS mos_content;
DROP TABLE IF EXISTS mos_content_frontpage;
DROP TABLE IF EXISTS mos_content_rating;
DROP TABLE IF EXISTS mos_core_acl_aro;
DROP TABLE IF EXISTS mos_core_acl_aro_groups;
DROP TABLE IF EXISTS mos_core_acl_aro_sections;
DROP TABLE IF EXISTS mos_core_acl_groups_aro_map;
DROP TABLE IF EXISTS mos_core_log_items;
DROP TABLE IF EXISTS mos_core_log_searches;
DROP TABLE IF EXISTS mos_groups;
DROP TABLE IF EXISTS mos_help;
DROP TABLE IF EXISTS mos_mambots;
DROP TABLE IF EXISTS mos_menu;
DROP TABLE IF EXISTS mos_messages;
DROP TABLE IF EXISTS mos_messages_cfg;
DROP TABLE IF EXISTS mos_modules;
DROP TABLE IF EXISTS mos_modules_menu;
DROP TABLE IF EXISTS mos_newsfeeds;
DROP TABLE IF EXISTS mos_newsflash;
DROP TABLE IF EXISTS mos_poll_data;
DROP TABLE IF EXISTS mos_poll_date;
DROP TABLE IF EXISTS mos_poll_menu;
DROP TABLE IF EXISTS mos_polls;
DROP TABLE IF EXISTS mos_sections;
DROP TABLE IF EXISTS mos_session;
DROP TABLE IF EXISTS mos_stats_agents;
DROP TABLE IF EXISTS mos_templates;
DROP TABLE IF EXISTS mos_template_positions;
DROP TABLE IF EXISTS mos_templates_menu;
DROP TABLE IF EXISTS mos_users;
DROP TABLE IF EXISTS mos_usertypes;
DROP TABLE IF EXISTS mos_weblinks;
